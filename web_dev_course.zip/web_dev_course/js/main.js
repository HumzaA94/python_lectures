function run(){
    x = document.getElementById('ingredientSelection');
    x.style.color = 'red';
    x.style.backgroundColor = '';

}

function mouse_gone(){
    x = document.getElementById('ingredientSelection');
    x.style.color = '';
    x.style.backgroundColor = 'red';
}

function run_1(){

    var password = "fasfkandasdxc lkn"

    alert(password);
}

function changeToBlue(x) {
    x.style.color ='blue';
    x.style.font = 'serif';
    x.style.fontSize = '20px';
}

function changeToOrange(x) {
    x.style.color ='orange';
    x.style.fontSize = '50px';
}  

function changeToOrange2() {
    document.getElementById("test2").style.color = 'orange';

}  


function loveTRC() {
    document.getElementById("empty").innerHTML = "attached message";
    console.log('message has been attached');
    }

function clear_logs(){
    console.clear();
}

function getDocumentElementbyID(string_id){
    var output = document.getElementById(string_id).value;
    return output
}

function output_name(){
    var first_name = getDocumentElementbyID("fname");
    var last_name = document.getElementById("lname").value;
    var output_string = "Hello " + first_name + " " + last_name;
    document.getElementById("empty").innerHTML = output_string;
}


function output(){
    var full_name = document.getElementById("name-input").value;
    var email = document.getElementById("name-input").value;

    var select_content = document.getElementById("cat_opinion").value;
    var text=select_content.options[select_content.selectedIndex].text;
    var output_string = full_name + " (" + email +") has selected " + text;
    document.getElementById("empty").innerHTML = output_string;
}


function username_password_checker(){
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    var string_message = "The value provided for username is " + username + " and the value provided for password is " + password;
    document.getElementById("message_input").innerHTML = string_message;
}










function full_name_email_checker(){
    var full_name = document.getElementById("full_name").value;
    var email = document.getElementById("email").value;
    var string_message = "The value provided for full_name is " + full_name + " and the value provided for email is " + email;
    document.getElementById("message_input_1").innerHTML = string_message;
}


function disappear(){
    document.getElementById("message_input_1").innerHTML = null;

}

function return_back_user_input(){
    var e = document.getElementById("feeling_options");
    var value = e.value;
    var text = e.options[e.selectedIndex].text;
    var string_message = "The person feels '" + text + "' when it comes to the picture.";
    document.getElementById("message_input_2").innerHTML = string_message;

}

